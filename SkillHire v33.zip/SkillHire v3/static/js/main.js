// Main JavaScript for SkillHire
document.addEventListener('DOMContentLoaded', function() {
    // Initialize mobile menu
    initMobileMenu();
    
    // Initialize flash message auto-dismiss
    initFlashMessages();
    
    // Initialize form enhancements
    initFormEnhancements();
    
    // Initialize image preview
    initImagePreview();
    
    // Initialize search functionality
    initSearchEnhancements();
    
    // Initialize scroll effects
    initScrollEffects();
});

// Mobile Navigation Menu
function initMobileMenu() {
    const mobileMenuToggle = document.getElementById('mobile-menu');
    const mobileNav = document.getElementById('mobile-nav');
    
    if (mobileMenuToggle && mobileNav) {
        mobileMenuToggle.addEventListener('click', function() {
            mobileNav.classList.toggle('active');
            
            // Toggle icon between menu and x
            const icon = mobileMenuToggle.querySelector('i');
            if (icon) {
                const isActive = mobileNav.classList.contains('active');
                icon.setAttribute('data-feather', isActive ? 'x' : 'menu');
                feather.replace();
            }
        });
        
        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenuToggle.contains(event.target) && !mobileNav.contains(event.target)) {
                mobileNav.classList.remove('active');
                const icon = mobileMenuToggle.querySelector('i');
                if (icon) {
                    icon.setAttribute('data-feather', 'menu');
                    feather.replace();
                }
            }
        });
        
        // Close mobile menu when window is resized to desktop
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                mobileNav.classList.remove('active');
                const icon = mobileMenuToggle.querySelector('i');
                if (icon) {
                    icon.setAttribute('data-feather', 'menu');
                    feather.replace();
                }
            }
        });
    }
}

// Flash Messages Auto-dismiss
function initFlashMessages() {
    const flashMessages = document.querySelectorAll('.flash');
    
    flashMessages.forEach(function(flash) {
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            if (flash.parentNode) {
                flash.style.animation = 'slideOut 0.3s ease forwards';
                setTimeout(function() {
                    if (flash.parentNode) {
                        flash.remove();
                    }
                }, 300);
            }
        }, 5000);
    });
}

// Form Enhancements
function initFormEnhancements() {
    // Password strength indicator
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    passwordInputs.forEach(function(input) {
        if (input.name === 'password') {
            addPasswordStrengthIndicator(input);
        }
    });
    
    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!validateForm(form)) {
                event.preventDefault();
            }
        });
    });
    
    // Real-time validation
    const inputs = document.querySelectorAll('input, textarea, select');
    inputs.forEach(function(input) {
        input.addEventListener('blur', function() {
            validateField(input);
        });
        
        input.addEventListener('input', function() {
            clearFieldError(input);
        });
    });
}

// Password Strength Indicator
function addPasswordStrengthIndicator(passwordInput) {
    const strengthDiv = document.createElement('div');
    strengthDiv.className = 'password-strength';
    strengthDiv.innerHTML = '<span class="strength-text"></span>';
    
    passwordInput.parentNode.appendChild(strengthDiv);
    
    passwordInput.addEventListener('input', function() {
        const password = passwordInput.value;
        const strength = calculatePasswordStrength(password);
        const strengthText = strengthDiv.querySelector('.strength-text');
        
        if (password.length === 0) {
            strengthText.textContent = '';
            strengthText.className = 'strength-text';
            return;
        }
        
        switch (strength) {
            case 'weak':
                strengthText.textContent = 'Weak password';
                strengthText.className = 'strength-text strength-weak';
                break;
            case 'medium':
                strengthText.textContent = 'Medium strength';
                strengthText.className = 'strength-text strength-medium';
                break;
            case 'strong':
                strengthText.textContent = 'Strong password';
                strengthText.className = 'strength-text strength-strong';
                break;
        }
    });
}

function calculatePasswordStrength(password) {
    if (password.length < 6) return 'weak';
    
    let score = 0;
    
    // Length
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;
    
    // Character types
    if (/[a-z]/.test(password)) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;
    
    if (score < 3) return 'weak';
    if (score < 5) return 'medium';
    return 'strong';
}

// Form Validation
function validateForm(form) {
    let isValid = true;
    const inputs = form.querySelectorAll('input, textarea, select');
    
    inputs.forEach(function(input) {
        if (!validateField(input)) {
            isValid = false;
        }
    });
    
    return isValid;
}

function validateField(field) {
    clearFieldError(field);
    
    // Required field validation
    if (field.hasAttribute('required') && !field.value.trim()) {
        showFieldError(field, 'This field is required');
        return false;
    }
    
    // Email validation
    if (field.type === 'email' && field.value.trim()) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(field.value)) {
            showFieldError(field, 'Please enter a valid email address');
            return false;
        }
    }
    
    // URL validation
    if (field.type === 'url' && field.value.trim()) {
        try {
            new URL(field.value);
        } catch {
            showFieldError(field, 'Please enter a valid URL');
            return false;
        }
    }
    
    // Password minimum length
    if (field.type === 'password' && field.value.length > 0 && field.value.length < 6) {
        showFieldError(field, 'Password must be at least 6 characters long');
        return false;
    }
    
    return true;
}

function showFieldError(field, message) {
    field.classList.add('error');
    
    let errorDiv = field.parentNode.querySelector('.form-error');
    if (!errorDiv) {
        errorDiv = document.createElement('div');
        errorDiv.className = 'form-error';
        field.parentNode.appendChild(errorDiv);
    }
    
    errorDiv.textContent = message;
}

function clearFieldError(field) {
    field.classList.remove('error');
    const errorDiv = field.parentNode.querySelector('.form-error');
    if (errorDiv) {
        errorDiv.remove();
    }
}

// Image Preview
function initImagePreview() {
    const fileInputs = document.querySelectorAll('input[type="file"]');
    
    fileInputs.forEach(function(input) {
        if (input.accept && input.accept.includes('image')) {
            input.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    showImagePreview(input, file);
                }
            });
        }
    });
}

function showImagePreview(input, file) {
    // Remove existing preview
    const existingPreview = input.parentNode.querySelector('.image-preview');
    if (existingPreview) {
        existingPreview.remove();
    }
    
    // Create new preview
    const reader = new FileReader();
    reader.onload = function(e) {
        const previewDiv = document.createElement('div');
        previewDiv.className = 'image-preview';
        previewDiv.innerHTML = `
            <img src="${e.target.result}" alt="Preview" style="width: 4rem; height: 4rem; border-radius: 50%; object-fit: cover; border: 2px solid var(--border); margin-top: 0.5rem;">
            <span style="margin-left: 0.5rem; font-size: 0.875rem; color: var(--text);">New photo selected</span>
        `;
        
        input.parentNode.appendChild(previewDiv);
    };
    
    reader.readAsDataURL(file);
}

// Search Enhancements
function initSearchEnhancements() {
    const searchForm = document.querySelector('.filters-form');
    const searchInput = document.querySelector('input[name="search"]');
    const professionSelect = document.querySelector('select[name="profession"]');
    
    if (searchForm && (searchInput || professionSelect)) {
        // Auto-submit on profession change
        if (professionSelect) {
            professionSelect.addEventListener('change', function() {
                searchForm.submit();
            });
        }
        
        // Search suggestions (if search input exists)
        if (searchInput) {
            let searchTimeout;
            
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                
                // Debounce search suggestions
                searchTimeout = setTimeout(function() {
                    // Could implement search suggestions here
                }, 300);
            });
        }
    }
}

// Scroll Effects
function initScrollEffects() {
    // Smooth scrolling for anchor links
    const anchorLinks = document.querySelectorAll('a[href^="#"]');
    
    anchorLinks.forEach(function(link) {
        link.addEventListener('click', function(e) {
            const href = link.getAttribute('href');
            if (href === '#') return;
            
            const target = document.querySelector(href);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Navbar background on scroll
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        let lastScrollY = window.scrollY;
        
        window.addEventListener('scroll', function() {
            const currentScrollY = window.scrollY;
            
            if (currentScrollY > 100) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
            
            lastScrollY = currentScrollY;
        });
    }
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Animation for slideOut
const style = document.createElement('style');
style.textContent = `
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .navbar.scrolled {
        background-color: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
    }
    
    .image-preview {
        display: flex;
        align-items: center;
        margin-top: 0.5rem;
        padding: 0.5rem;
        background-color: var(--light-gray);
        border-radius: 0.5rem;
    }
    
    .form-error {
        color: var(--danger);
        font-size: 0.875rem;
        margin-top: 0.25rem;
        display: flex;
        align-items: center;
        gap: 0.25rem;
    }
    
    .form-error::before {
        content: '⚠';
        font-size: 0.75rem;
    }
    
    input.error,
    textarea.error,
    select.error {
        border-color: var(--danger);
        box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
    }
    
    .password-strength {
        margin-top: 0.5rem;
        font-size: 0.875rem;
    }
    
    .strength-weak {
        color: var(--danger);
    }
    
    .strength-medium {
        color: var(--warning);
    }
    
    .strength-strong {
        color: var(--success);
    }
`;
document.head.appendChild(style);

// Export functions for potential use elsewhere
window.SkillHire = {
    validateForm,
    validateField,
    showFieldError,
    clearFieldError,
    debounce,
    throttle
};
