// Admin Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts if Chart.js is available
    if (typeof Chart !== 'undefined') {
        initCharts();
    }
    
    // Initialize admin-specific functionality
    initAdminFeatures();
    
    // Initialize data refresh
    initDataRefresh();
});

// Initialize Charts
function initCharts() {
    initMonthlyChart();
    initProfessionChart();
}

// Monthly Registrations Chart
function initMonthlyChart() {
    const canvas = document.getElementById('monthlyChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Fetch data from API
    fetch('/admin/api/stats')
        .then(response => response.json())
        .then(data => {
            const monthlyData = data.monthly_registrations || [];
            
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: monthlyData.map(item => item.month),
                    datasets: [{
                        label: 'Professional Registrations',
                        data: monthlyData.map(item => item.count),
                        borderColor: '#2563EB',
                        backgroundColor: 'rgba(37, 99, 235, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#2563EB',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 6,
                        pointHoverRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleColor: '#ffffff',
                            bodyColor: '#ffffff',
                            borderColor: '#2563EB',
                            borderWidth: 1,
                            cornerRadius: 8,
                            displayColors: false,
                            callbacks: {
                                title: function(context) {
                                    return context[0].label;
                                },
                                label: function(context) {
                                    const count = context.parsed.y;
                                    return `${count} registration${count !== 1 ? 's' : ''}`;
                                }
                            }
                        }
                    },
                    scales: {
                        x: {
                            grid: {
                                display: false
                            },
                            border: {
                                color: '#E2E8F0'
                            },
                            ticks: {
                                color: '#64748B',
                                font: {
                                    family: 'Inter, sans-serif',
                                    size: 12
                                }
                            }
                        },
                        y: {
                            beginAtZero: true,
                            grid: {
                                color: '#F1F5F9'
                            },
                            border: {
                                color: '#E2E8F0'
                            },
                            ticks: {
                                color: '#64748B',
                                font: {
                                    family: 'Inter, sans-serif',
                                    size: 12
                                },
                                stepSize: 1
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    }
                }
            });
        })
        .catch(error => {
            console.error('Error fetching monthly chart data:', error);
            showChartError(canvas, 'Failed to load monthly data');
        });
}

// Profession Distribution Chart
function initProfessionChart() {
    const canvas = document.getElementById('professionChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    
    // Fetch data from API
    fetch('/admin/api/stats')
        .then(response => response.json())
        .then(data => {
            const professionData = data.profession_distribution || [];
            
            if (professionData.length === 0) {
                showChartError(canvas, 'No profession data available');
                return;
            }
            
            // Define colors for different professions
            const colors = [
                '#2563EB', '#059669', '#7C3AED', '#F59E0B', 
                '#EF4444', '#10B981', '#8B5CF6', '#F97316',
                '#6366F1', '#EC4899', '#14B8A6', '#F43F5E'
            ];
            
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: professionData.map(item => item.profession.charAt(0).toUpperCase() + item.profession.slice(1)),
                    datasets: [{
                        data: professionData.map(item => item.count),
                        backgroundColor: colors.slice(0, professionData.length),
                        borderColor: '#ffffff',
                        borderWidth: 2,
                        hoverBorderWidth: 3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right',
                            labels: {
                                padding: 20,
                                usePointStyle: true,
                                pointStyle: 'circle',
                                font: {
                                    family: 'Inter, sans-serif',
                                    size: 12
                                },
                                color: '#1E293B'
                            }
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleColor: '#ffffff',
                            bodyColor: '#ffffff',
                            borderColor: '#2563EB',
                            borderWidth: 1,
                            cornerRadius: 8,
                            displayColors: true,
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.parsed;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = ((value / total) * 100).toFixed(1);
                                    return `${label}: ${value} (${percentage}%)`;
                                }
                            }
                        }
                    },
                    cutout: '50%',
                    animation: {
                        animateRotate: true,
                        animateScale: false
                    }
                }
            });
        })
        .catch(error => {
            console.error('Error fetching profession chart data:', error);
            showChartError(canvas, 'Failed to load profession data');
        });
}

// Show chart error
function showChartError(canvas, message) {
    const container = canvas.parentElement;
    container.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 200px; color: #64748B;">
            <svg width="48" height="48" fill="none" stroke="currentColor" viewBox="0 0 24 24" style="margin-bottom: 1rem; opacity: 0.5;">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.464 0L4.35 16.5c-.77.833.192 2.5 1.732 2.5z"></path>
            </svg>
            <p style="text-align: center; margin: 0;">${message}</p>
        </div>
    `;
}

// Initialize Admin Features
function initAdminFeatures() {
    // Initialize verification form handlers
    initVerificationForms();
    
    // Initialize stat card animations
    initStatCardAnimations();
    
    // Initialize action card interactions
    initActionCards();
    
    // Initialize data tables if any
    initDataTables();
}

// Verification Forms
function initVerificationForms() {
    const verificationForms = document.querySelectorAll('.verification-form');
    
    verificationForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const action = e.submitter?.value;
            const professionalName = form.closest('.verification-card')?.querySelector('h3')?.textContent;
            
            if (action && professionalName) {
                const actionText = action === 'approve' ? 'approve' : 'reject';
                const confirmMessage = `Are you sure you want to ${actionText} ${professionalName}?`;
                
                if (!confirm(confirmMessage)) {
                    e.preventDefault();
                    return;
                }
            }
            
            // Show loading state
            const submitBtn = e.submitter;
            if (submitBtn) {
                const originalText = submitBtn.textContent;
                submitBtn.disabled = true;
                submitBtn.textContent = 'Processing...';
                
                // Reset button state if form submission fails
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.textContent = originalText;
                }, 5000);
            }
        });
    });
}

// Stat Card Animations
function initStatCardAnimations() {
    const statCards = document.querySelectorAll('.stat-card');
    
    // Animate numbers on load
    statCards.forEach(card => {
        const numberElement = card.querySelector('h3');
        if (numberElement) {
            animateNumber(numberElement);
        }
    });
}

function animateNumber(element) {
    const finalNumber = parseInt(element.textContent);
    if (isNaN(finalNumber)) return;
    
    const duration = 1500;
    const increment = finalNumber / (duration / 16);
    let current = 0;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= finalNumber) {
            element.textContent = finalNumber;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 16);
}

// Action Cards
function initActionCards() {
    const actionCards = document.querySelectorAll('.action-card');
    
    actionCards.forEach(card => {
        card.addEventListener('click', function(e) {
            // Add click effect
            card.style.transform = 'scale(0.98)';
            setTimeout(() => {
                card.style.transform = '';
            }, 150);
        });
    });
}

// Data Tables (placeholder for future enhancement)
function initDataTables() {
    // Could implement sortable tables, pagination, etc.
    const tables = document.querySelectorAll('table');
    
    tables.forEach(table => {
        // Add sorting functionality if needed
        addTableSorting(table);
    });
}

function addTableSorting(table) {
    const headers = table.querySelectorAll('th');
    
    headers.forEach((header, index) => {
        if (header.textContent.trim()) {
            header.style.cursor = 'pointer';
            header.addEventListener('click', () => {
                sortTable(table, index);
            });
        }
    });
}

function sortTable(table, columnIndex) {
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const isNumeric = rows.every(row => {
        const cell = row.cells[columnIndex];
        return cell && !isNaN(parseFloat(cell.textContent));
    });
    
    rows.sort((a, b) => {
        const aText = a.cells[columnIndex]?.textContent.trim() || '';
        const bText = b.cells[columnIndex]?.textContent.trim() || '';
        
        if (isNumeric) {
            return parseFloat(aText) - parseFloat(bText);
        } else {
            return aText.localeCompare(bText);
        }
    });
    
    rows.forEach(row => tbody.appendChild(row));
}

// Data Refresh
function initDataRefresh() {
    // Auto-refresh stats every 5 minutes
    setInterval(refreshStats, 5 * 60 * 1000);
    
    // Manual refresh button
    const refreshBtn = document.getElementById('refresh-data');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            refreshStats();
            showRefreshFeedback(refreshBtn);
        });
    }
}

function refreshStats() {
    // Refresh chart data
    if (typeof Chart !== 'undefined') {
        Chart.getChart('monthlyChart')?.destroy();
        Chart.getChart('professionChart')?.destroy();
        initCharts();
    }
    
    // Could refresh other dynamic content here
}

function showRefreshFeedback(button) {
    const originalText = button.textContent;
    button.textContent = 'Refreshing...';
    button.disabled = true;
    
    setTimeout(() => {
        button.textContent = 'Refreshed!';
        setTimeout(() => {
            button.textContent = originalText;
            button.disabled = false;
        }, 1000);
    }, 1500);
}

// Utility functions for admin
function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

function exportData(type) {
    // Placeholder for data export functionality
    console.log(`Exporting ${type} data...`);
    
    // Could implement CSV/Excel export here
    fetch(`/admin/export/${type}`)
        .then(response => response.blob())
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `skillhire_${type}_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        })
        .catch(error => {
            console.error('Export failed:', error);
            alert('Export failed. Please try again.');
        });
}

// Session management
function checkAdminSession() {
    // Check if admin session is still valid
    fetch('/admin/check-session')
        .then(response => {
            if (!response.ok) {
                // Session expired, redirect to login
                window.location.href = '/admin/login';
            }
        })
        .catch(error => {
            console.error('Session check failed:', error);
        });
}

// Check session every 10 minutes
setInterval(checkAdminSession, 10 * 60 * 1000);

// Export admin utilities
window.AdminUtils = {
    refreshStats,
    exportData,
    formatNumber,
    animateNumber
};

// Add some custom styles for admin features
const adminStyles = document.createElement('style');
adminStyles.textContent = `
    .stat-card h3 {
        transition: all 0.3s ease;
    }
    
    .action-card {
        transition: transform 0.15s ease;
    }
    
    .verification-form button:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }
    
    .chart-loading {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 200px;
        color: #64748B;
    }
    
    .chart-loading::after {
        content: '';
        width: 2rem;
        height: 2rem;
        border: 2px solid transparent;
        border-top-color: #2563EB;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin-left: 0.5rem;
    }
    
    @keyframes spin {
        to {
            transform: rotate(360deg);
        }
    }
    
    th[data-sortable] {
        user-select: none;
        position: relative;
    }
    
    th[data-sortable]:hover {
        background-color: var(--light-gray);
    }
    
    th[data-sortable]:after {
        content: '↕';
        position: absolute;
        right: 0.5rem;
        opacity: 0.3;
    }
    
    th[data-sort-direction="asc"]:after {
        content: '↑';
        opacity: 1;
    }
    
    th[data-sort-direction="desc"]:after {
        content: '↓';
        opacity: 1;
    }
`;
document.head.appendChild(adminStyles);
