import os
import uuid
from datetime import datetime, timedelta
from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from models import User, Professional, Service, AdminSession
from flask import current_app
from extensions import db

# Admin credentials
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "123456"

# Allowed file extensions for profile photos
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Create a Blueprint
main_blueprint = Blueprint('main', __name__)

@main_blueprint.route('/')
def index():
    # Get approved professionals for display
    approved_professionals = Professional.query.filter_by(verification_status='approved').limit(6).all()
    return render_template('index.html', professionals=approved_professionals)

@main_blueprint.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        user_type = request.form['user_type']
        
        # Check if user already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'error')
            return render_template('register.html')
        
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'error')
            return render_template('register.html')
        
        # Create new user
        user = User(username=username, email=email, user_type=user_type)
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('main.login'))
    
    return render_template('register.html')

@main_blueprint.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['user_type'] = user.user_type
            
            flash('Login successful!', 'success')
            if user.user_type == 'professional':
                return redirect(url_for('main.profile'))
            else:
                return redirect(url_for('main.services'))
        else:
            flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@main_blueprint.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('main.index'))

@main_blueprint.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session or session.get('user_type') != 'professional':
        flash('Please login as a professional to access this page.', 'error')
        return redirect(url_for('main.login'))
    
    user = User.query.get(session['user_id'])
    professional = Professional.query.filter_by(user_id=user.id).first()
    
    if request.method == 'POST':
        # Handle profile creation/update
        full_name = request.form['full_name']
        profession = request.form['profession']
        bio = request.form['bio']
        location = request.form['location']
        # Convert rupee input back to USD for storage (divide by 83)
        hourly_rate_input = request.form['hourly_rate']
        hourly_rate = float(hourly_rate_input) / 83 if hourly_rate_input else None
        verification_documents = request.form['verification_documents']
        
        # Handle file upload
        profile_photo = None
        if 'profile_photo' in request.files:
            file = request.files['profile_photo']
            if file and file.filename != '' and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                # Add timestamp to avoid conflicts
                filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{filename}"
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(file_path)
                profile_photo = filename
        
        if professional:
            # Update existing profile
            professional.full_name = full_name
            professional.profession = profession
            professional.bio = bio
            professional.location = location
            professional.hourly_rate = hourly_rate
            professional.verification_documents = verification_documents
            if profile_photo:
                professional.profile_photo = profile_photo
            professional.updated_at = datetime.utcnow()
        else:
            # Create new professional profile
            professional = Professional(
                user_id=user.id,
                full_name=full_name,
                profession=profession,
                bio=bio,
                location=location,
                hourly_rate=hourly_rate,
                profile_photo=profile_photo,
                verification_documents=verification_documents
            )
            db.session.add(professional)
        
        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('main.profile'))
    
    return render_template('profile.html', professional=professional)

@main_blueprint.route('/services')
def services():
    # Get filter parameters
    profession_filter = request.args.get('profession', '')
    search_query = request.args.get('search', '')
    location_filter = request.args.get('location', '')
    pincode_filter = request.args.get('pincode', '')
    
    # Base query for approved professionals
    query = Professional.query.filter_by(verification_status='approved')
    
    # Apply filters
    if profession_filter:
        query = query.filter(Professional.profession == profession_filter)
    
    if search_query:
        # Enhanced pattern-based search
        search_pattern = f'%{search_query}%'
        query = query.filter(
            db.or_(
                Professional.full_name.ilike(search_pattern),
                Professional.bio.ilike(search_pattern),
                Professional.profession.ilike(search_pattern),
                Professional.location.ilike(search_pattern)
            )
        )
    
    if location_filter:
        # Location-based filtering
        location_pattern = f'%{location_filter}%'
        query = query.filter(Professional.location.ilike(location_pattern))
    
    if pincode_filter:
        # Pincode-based filtering
        query = query.filter(Professional.location.ilike(f'%{pincode_filter}%'))
    
    professionals = query.all()
    
    # Get unique professions for filter dropdown
    professions = db.session.query(Professional.profession).filter_by(verification_status='approved').distinct().all()
    professions = [p[0] for p in professions]
    
    return render_template('services.html', 
                         professionals=professionals, 
                         professions=professions,
                         current_profession=profession_filter,
                         current_search=search_query,
                         current_location=location_filter,
                         current_pincode=pincode_filter)

@main_blueprint.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            # Create admin session
            session_id = str(uuid.uuid4())
            admin_session = AdminSession(
                session_id=session_id,
                expires_at=datetime.utcnow() + timedelta(hours=24)
            )
            db.session.add(admin_session)
            db.session.commit()
            
            session['admin_session_id'] = session_id
            flash('Admin login successful!', 'success')
            return redirect(url_for('main.admin_dashboard'))
        else:
            flash('Invalid admin credentials', 'error')
    
    return render_template('admin_login.html')

@main_blueprint.route('/admin/logout')
def admin_logout():
    if 'admin_session_id' in session:
        # Remove admin session from database
        AdminSession.query.filter_by(session_id=session['admin_session_id']).delete()
        db.session.commit()
        session.pop('admin_session_id', None)
    
    flash('Admin logged out successfully.', 'info')
    return redirect(url_for('main.index'))

def check_admin_session():
    if 'admin_session_id' not in session:
        return False
    
    admin_session = AdminSession.query.filter_by(session_id=session['admin_session_id']).first()
    if not admin_session or admin_session.expires_at < datetime.utcnow():
        return False
    
    return True

@main_blueprint.route('/admin/dashboard')
def admin_dashboard():
    if not check_admin_session():
        flash('Please login as admin to access this page.', 'error')
        return redirect(url_for('main.admin_login'))
    
    # Get analytics data
    total_professionals = Professional.query.count()
    pending_verifications = Professional.query.filter_by(verification_status='pending').count()
    approved_professionals = Professional.query.filter_by(verification_status='approved').count()
    rejected_professionals = Professional.query.filter_by(verification_status='rejected').count()
    total_users = User.query.count()
    
    # Get profession distribution
    profession_stats = db.session.query(
        Professional.profession, 
        db.func.count(Professional.id)
    ).filter_by(verification_status='approved').group_by(Professional.profession).all()
    
    # Get recent registrations (last 30 days)
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    recent_registrations = Professional.query.filter(
        Professional.created_at >= thirty_days_ago
    ).count()
    
    return render_template('admin_dashboard.html',
                         total_professionals=total_professionals,
                         pending_verifications=pending_verifications,
                         approved_professionals=approved_professionals,
                         rejected_professionals=rejected_professionals,
                         total_users=total_users,
                         profession_stats=profession_stats,
                         recent_registrations=recent_registrations)

@main_blueprint.route('/admin/verify')
def admin_verify():
    if not check_admin_session():
        flash('Please login as admin to access this page.', 'error')
        return redirect(url_for('main.admin_login'))
    
    # Get all professionals pending verification
    pending_professionals = Professional.query.filter_by(verification_status='pending').all()
    
    return render_template('admin_verify.html', professionals=pending_professionals)

@main_blueprint.route('/admin/verify/<int:professional_id>', methods=['POST'])
def admin_verify_professional(professional_id):
    if not check_admin_session():
        flash('Please login as admin to access this page.', 'error')
        return redirect(url_for('main.admin_login'))
    
    professional = Professional.query.get_or_404(professional_id)
    action = request.form['action']
    admin_notes = request.form.get('admin_notes', '')
    
    if action == 'approve':
        professional.verification_status = 'approved'
        flash(f'Professional {professional.full_name} has been approved.', 'success')
    elif action == 'reject':
        professional.verification_status = 'rejected'
        flash(f'Professional {professional.full_name} has been rejected.', 'warning')
    
    professional.admin_notes = admin_notes
    professional.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    return redirect(url_for('main.admin_verify'))

@main_blueprint.route('/professional/<int:professional_id>')
def professional_details(professional_id):
    professional = Professional.query.get_or_404(professional_id)
    
    # Only show details for approved professionals
    if professional.verification_status != 'approved':
        flash('This professional is not available.', 'error')
        return redirect(url_for('main.services'))
    
    # Get all services for this professional
    services = Service.query.filter_by(professional_id=professional_id).all()
    
    return render_template('professional_details.html', 
                         professional=professional, 
                         services=services)

@main_blueprint.route('/contact/<int:professional_id>', methods=['GET', 'POST'])
def contact_professional(professional_id):
    if 'user_id' not in session:
        flash('Please login to contact professionals.', 'error')
        return redirect(url_for('main.login'))
    
    professional = Professional.query.get_or_404(professional_id)
    
    # Only allow contact for approved professionals
    if professional.verification_status != 'approved':
        flash('This professional is not available.', 'error')
        return redirect(url_for('main.services'))
    
    if request.method == 'POST':
        # In a real application, you would send an email or create a message record
        # For now, we'll just show a success message
        project_title = request.form.get('project_title')
        contact_name = request.form.get('contact_name')
        
        flash(f'Your message about "{project_title}" has been sent to {professional.full_name}. They will contact you soon!', 'success')
        return redirect(url_for('main.professional_details', professional_id=professional_id))
    
    return render_template('contact_professional.html', professional=professional)

@main_blueprint.route('/admin/api/stats')
def admin_api_stats():
    if not check_admin_session():
        return jsonify({'error': 'Unauthorized'}), 401
    
    # Get monthly registration data for the last 12 months
    monthly_data = []
    for i in range(12):
        month_start = datetime.utcnow().replace(day=1) - timedelta(days=30*i)
        month_end = (month_start + timedelta(days=31)).replace(day=1)
        
        count = Professional.query.filter(
            Professional.created_at >= month_start,
            Professional.created_at < month_end
        ).count()
        
        monthly_data.append({
            'month': month_start.strftime('%b %Y'),
            'count': count
        })
    
    monthly_data.reverse()
    
    # Get profession distribution
    profession_data = db.session.query(
        Professional.profession, 
        db.func.count(Professional.id)
    ).filter_by(verification_status='approved').group_by(Professional.profession).all()
    
    return jsonify({
        'monthly_registrations': monthly_data,
        'profession_distribution': [{'profession': p[0], 'count': p[1]} for p in profession_data]
    })

# Error handlers
@main_blueprint.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@main_blueprint.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500
